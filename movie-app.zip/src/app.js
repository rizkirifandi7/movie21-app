import "regenerator-runtime";
import "./css/style.css";
import main from "./scripts/view/main.js";

document.addEventListener("DOMContentLoaded", main);
